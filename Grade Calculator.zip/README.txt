Steps on how to run the Program "Grade Calculator"
1. Download and Import the folder to Virtual studio Code
2. Navigate to the folder and click on the app.py and click the run button
3. Copy this Link: http://127.0.0.1:5000/ and paste it on your Browser
4. Type your Prelim Grade from 0-100 on the space then hit the submit button
5. after you hit the submit button you will see the required combined % of what you need to pass the whole school year(midterm-finals)
6. that's all 